/* 
 * File:   newPAN.h
 * Author: Benoit
 *
 * Created on February 7, 2019, 3:28 PM
 */

#ifndef NEWPAN_H
#define	NEWPAN_H

#include <string.h>
#include "system.h"
#include "codes library.h"
#include "system_config.h"
#include "miwi/miwi_api.h"
#include "soft_uart.h"





void newPan();



#endif