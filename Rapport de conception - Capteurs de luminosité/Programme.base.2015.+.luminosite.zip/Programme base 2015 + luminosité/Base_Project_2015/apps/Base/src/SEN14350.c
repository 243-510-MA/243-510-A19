//***************************************************************************************
//* Programme adapt� par:
//*   Nicolas Brochu
//*   Bruno St-Georges
//*   Jonathan Galipeau
//*
//* Date: 5 d�cembre 2019
//*
//* Librairie bas� sur la librairie de SparkFun APDS9301
//*  Lien: https://github.com/sparkfun/SparkFun_APDS9301_Library
//*
//* D�vellop� pour le module:
//*  APDS-9301: https://learn.sparkfun.com/tutorials/apds-9301-sensor-hookup-guide/all
//*   - Bas� sur le capteur: SEN14350
//*
//***************************************************************************************

#include "SEN14350.h"
#include "soft_i2c.h"
#include "system.h"
#include "math.h"


// D�fini le mode du capteur (Actif ou en Veille)
// powEn: POW_ON/POW_OFF ; _address: Adresse du capteur
void powerEnable(powEnable powEn, char _address)
{
    //char data = getRegister(_address, CONTROL_REG);
    if (powEn == POW_OFF)
    {
        setRegister(_address, CONTROL_REG, 0);   // D�sactivation Module; Mode veille
    } 
    else
    {
        setRegister(_address, CONTROL_REG, 3);   // Activation Module    
    }                  
}


// D�fini le gain interne du capteur
// gainLevel: HIGH_GAIN/LOW_GAIN ; _address: Adresse du capteur
void setGain(gain gainLevel, char _address)
{
    uint8_t regVal = getRegister(_address, TIMING_REG);
    if (gainLevel == LOW_GAIN) regVal &= ~0x10;
    else                       regVal |= 0x10;
    setRegister(_address, TIMING_REG, regVal);
}


// R�cup�re le gain interne du capteur
// _address: Adresse du capteur
// return: gain -> HIGH_GAIN/LOW_GAIN
gain getGain(char _address)  // V�rifier 
{
    uint8_t regVal = getRegister(_address, TIMING_REG);
    regVal &= 0x10;
    if (regVal != 0) return HIGH_GAIN;
    else             return LOW_GAIN;
}


// R�cup�re la valeur du capteur 0 du module
// _address: Adresse du capteur
// return: unsigned int -> Valeur du capteur 0
unsigned int readCH0Level(char _address)
{
    return getRegister(_address, DATA0LOW_REG) | (getRegister(_address, DATA0HI_REG) << 8);
}


// R�cup�re la valeur du capteur 1 du module
// _address: Adresse du capteur
// return: unsigned int -> Valeur du capteur 1
unsigned int readCH1Level(char _address)
{
    return getRegister(_address, DATA1LOW_REG) | (getRegister(_address, DATA1HI_REG) << 8);
}


// R�cup�re le niveau de lux
// _address: Adresse du capteur
// return: float -> Niveau de lux d�cod�
float readluxLevel(char _address)
{
  float ch0 = (float)readCH0Level(_address);
  float ch1 = (float)readCH1Level(_address);
  
  float ratio = ch1/ch0;

  if (getGain(_address) == LOW_GAIN) 
  {
    ch0 *= 16;
    ch1 *= 16;
  }
  
  float luxVal = 0.0;
  if (ratio <= 0.5)
  {
    luxVal = (0.0304 * ch0) - ((0.062 * ch0) * (pow((ch1/ch0), 1.4)));
  }  
  else if (ratio <= 0.61)
  {
    luxVal = (0.0224 * ch0) - (0.031 * ch1);
  }
  else if (ratio <= 0.8)
  {
    luxVal = (0.0128 * ch0) - (0.0153 * ch1);
  }
  else if (ratio <= 1.3)
  {
    luxVal = (0.00146 * ch0) - (0.00112*ch1);
  }

  return luxVal;
}


// R�cup�re la valeur d'un registre
// _addresse: Adresse du module ; regAddress: Adresse du registre � lire
// return: unsigned int -> Valeur du registre pr�cis�
unsigned int getRegister(char _address, char regAddress)
{
  i2cStart();
  i2cWriteByte((_address << 1) + WRITE); // Slave Address Write
  i2cAck(); // ACK du slave
  i2cWriteByte(regAddress);   // Command Code
  i2cAck(); // ACK du slave
  
  i2cStart(); // Repeat Start
  i2cWriteByte((_address << 1) + READ);
  i2cAck();   // ACK du slave
  char data = i2cReadByte();
  //i2cAck();   // ACK du master pour confirmer la r�ception des donn�es
  i2cStop();  // Lib�re le bus I2C
  return data;
}


// D�fini la valeur d'un registre
// _address: Adresse du module ; regAddress: Adresse du registre � modifier ; newVal: Nouvelle valeur souhait� dans le registre
void setRegister(char _address, char regAddress, char newVal)
{
    i2cStart();
    i2cWriteByte((_address << 1) + WRITE);
    i2cAck(); // ACK du slave
    i2cWriteByte(regAddress);
    i2cAck(); // ACK du slave
    i2cWriteByte(newVal);
    i2cAck();   // ACK du slave
    i2cStop();  // Lib�re le bus I2C
}
