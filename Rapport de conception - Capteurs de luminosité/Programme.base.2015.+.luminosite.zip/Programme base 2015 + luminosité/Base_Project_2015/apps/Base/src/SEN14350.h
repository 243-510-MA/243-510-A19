//***************************************************************************************
//* Header adapt� par:
//*   Nicolas Brochu
//*   Bruno St-Georges
//*   Jonathan Galipeau
//*
//* Date: 5 d�cembre 2019
//*
//* Librairie bas� sur la librairie de SparkFun APDS9301
//*  Lien: https://github.com/sparkfun/SparkFun_APDS9301_Library
//*
//* D�vellop� pour le module:
//*  APDS-9301: https://learn.sparkfun.com/tutorials/apds-9301-sensor-hookup-guide/all
//*   - Bas� sur le capteur: SEN14350
//*
//***************************************************************************************
#ifndef SEN14350_H
#define	SEN14350_H

#define CONTROL_REG        0x80
#define TIMING_REG         0x81
#define THRESHLOWLOW_REG   0x82
#define THRESHLOWHI_REG    0x83
#define THRESHHILOW_REG    0x84
#define THRESHHIHI_REG     0x85
#define INTERRUPT_REG      0x86
#define ID_REG             0x8A
#define DATA0LOW_REG       0x8C
#define DATA0HI_REG        0x8D
#define DATA1LOW_REG       0x8E
#define DATA1HI_REG        0x8F

#define WRITE 0
#define READ  1

// Typedefs for this class
typedef enum {LOW_GAIN, HIGH_GAIN} gain;
typedef enum {POW_OFF, POW_ON} powEnable;


void powerEnable(powEnable powEn, char _address);

void setGain(gain gainLevel, char _address);

gain getGain(char _address);

unsigned int readCH0Level(char _address);

unsigned int readCH1Level(char _address);

float readluxLevel(char _address);

unsigned int getRegister(char _address, char regAddress);

void setRegister(char _address, char regAddress, char newVal);


#endif	/* SEN14350_H */
