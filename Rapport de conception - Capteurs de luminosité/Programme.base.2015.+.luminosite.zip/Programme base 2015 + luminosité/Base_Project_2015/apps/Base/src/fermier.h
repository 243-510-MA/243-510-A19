// Fichier header du module fermier
#ifndef _FERMIER_H
#define _FERMIER_H

void fermier(void);

#endif
